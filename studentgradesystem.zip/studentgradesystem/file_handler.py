import csv
import os
from student import Student


FILE_NAME = "students.csv"


def save_students(students):
    """
    Save all student records into CSV file.
    """

    try:

        with open(
            FILE_NAME,
            "w",
            newline="",
            encoding="utf-8"
        ) as file:

            writer = csv.writer(file)


            writer.writerow([
                "ID",
                "Name",
                "Subject",
                "Grade"
            ])


            for student in students:

                if student.grades:

                    for subject, grade in student.grades.items():

                        writer.writerow([
                            student.student_id,
                            student.name,
                            subject,
                            grade
                        ])

                else:

                    writer.writerow([
                        student.student_id,
                        student.name,
                        "",
                        ""
                    ])


        print("\n Student data saved successfully!")


    except Exception as error:

        print(
            f"\nError saving data: {error}"
        )



def load_students():

    """
    Load students from CSV file.
    Returns a list of Student objects.
    """

    students = []


    if not os.path.exists(FILE_NAME):

        return students


    try:

        with open(
            FILE_NAME,
            "r",
            newline="",
            encoding="utf-8"
        ) as file:


            reader = csv.DictReader(file)


            for row in reader:


                student = None


                # Check if student already exists

                for existing in students:

                    if existing.student_id == row["ID"]:

                        student = existing
                        break



                # Create new student

                if student is None:

                    student = Student(
                        row["ID"],
                        row["Name"]
                    )

                    students.append(student)



                # Add grade if available

                if row["Subject"]:

                    student.add_grade(
                        row["Subject"],
                        float(row["Grade"])
                    )



    except Exception as error:

        print(
            f"\nError loading data: {error}"
        )


    return students