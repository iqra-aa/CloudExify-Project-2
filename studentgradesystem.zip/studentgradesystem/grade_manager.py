from student import Student


class GradeManager:

    def __init__(self):
        self.students = []


    def add_student(self, student_id, name):
        student = Student(student_id, name)

        self.students.append(student)

        print("\n Student added successfully!")


    def find_student(self, search_value):

        for student in self.students:

            if (
                student.student_id == search_value
                or student.name.lower() == search_value.lower()
            ):
                return student

        return None


    def remove_student(self, student_id):

        student = self.find_student(student_id)

        if student:

            self.students.remove(student)

            print("\n Student removed successfully!")

        else:
            print("\n Student not found.")


    def edit_student(self, student_id):

        student = self.find_student(student_id)

        if student:

            print("\nLeave blank to keep old value.")

            new_name = input(
                f"Name ({student.name}): "
            )

            if new_name:
                student.name = new_name

            print("\n Student updated!")

        else:
            print("\n Student not found.")


    def add_grade(self, student_id, subject, grade):

        student = self.find_student(student_id)

        if student:

            student.add_grade(
                subject,
                grade
            )

            print("\n Grade added!")

        else:

            print("\n Student not found.")


    def display_all_students(self):

        if not self.students:

            print("\nNo students available.")

            return


        for student in self.students:

            student.display_student()


    def class_report(self):

        if not self.students:

            print("\nNo student data available.")

            return


        averages = []

        for student in self.students:

            averages.append(
                student.calculate_average()
            )


        print("\n========== CLASS REPORT ==========")

        print(
            f"Highest Average: {max(averages):.2f}"
        )

        print(
            f"Lowest Average : {min(averages):.2f}"
        )

        print(
            f"Class Average  : {sum(averages)/len(averages):.2f}"
        )


    def sort_students(self, reverse=False):

        sorted_students = sorted(
            self.students,
            key=lambda student:
            student.calculate_average(),
            reverse=reverse
        )


        print("\n====== SORTED STUDENTS ======")


        for student in sorted_students:

            print(
                f"{student.name} - "
                f"{student.calculate_average():.2f}"
            )


    def get_students(self):

        return self.students


    def load_students(self, students):

        self.students = students