from grade_manager import GradeManager
from file_handler import save_students, load_students
from utils import (
    print_header,
    get_non_empty_input,
    get_float,
    get_int,
    confirm_action
)


def show_menu():

    print("""
1. Add Student
2. Add Grade
3. View All Students
4. Search Student
5. Edit Student
6. Remove Student
7. Class Report
8. Sort Students
9. Save Data
10. Exit
""")


def main():

    manager = GradeManager()

    # Load saved data
    students = load_students()
    manager.load_students(students)


    print_header(
        "STUDENT GRADE MANAGEMENT SYSTEM"
    )


    if students:
        print(
            f"Loaded {len(students)} students."
        )


    while True:

        show_menu()

        choice = input(
            "Enter your choice: "
        ).strip()



        # Add student
        if choice == "1":

            print_header(
                "ADD STUDENT"
            )

            student_id = get_non_empty_input(
                "Student ID: "
            )

            name = get_non_empty_input(
                "Student Name: "
            )

            manager.add_student(
                student_id,
                name
            )



        # Add grade
        elif choice == "2":

            print_header(
                "ADD GRADE"
            )

            student_id = get_non_empty_input(
                "Student ID: "
            )

            subject = get_non_empty_input(
                "Subject: "
            )

            grade = get_float(
                "Grade: "
            )

            manager.add_grade(
                student_id,
                subject,
                grade
            )



        # View students
        elif choice == "3":

            print_header(
                "ALL STUDENTS"
            )

            manager.display_all_students()



        # Search student
        elif choice == "4":

            print_header(
                "SEARCH STUDENT"
            )

            keyword = get_non_empty_input(
                "Enter ID or Name: "
            )


            student = manager.find_student(
                keyword
            )


            if student:
                student.display_student()

            else:
                print(
                    "Student not found."
                )



        # Edit student
        elif choice == "5":

            print_header(
                "EDIT STUDENT"
            )

            student_id = get_non_empty_input(
                "Student ID: "
            )

            manager.edit_student(
                student_id
            )



        # Remove student
        elif choice == "6":

            print_header(
                "REMOVE STUDENT"
            )

            student_id = get_non_empty_input(
                "Student ID: "
            )


            if confirm_action(
                "Delete this student?"
            ):

                manager.remove_student(
                    student_id
                )

            else:

                print(
                    "Cancelled."
                )



        # Class report
        elif choice == "7":

            print_header(
                "CLASS REPORT"
            )

            manager.class_report()



        # Sort students
        elif choice == "8":

            print_header(
                "SORT STUDENTS"
            )


            order = input(
                "Highest first? (Y/N): "
            ).upper()


            manager.sort_students(
                reverse=(order == "Y")
            )



        # Save data
        elif choice == "9":

            save_students(
                manager.get_students()
            )



        # Exit
        elif choice == "10":

            print(
                "\nSaving data..."
            )

            save_students(
                manager.get_students()
            )


            print(
                "Thank you for using the system!"
            )

            break



        else:

            print(
                "\nInvalid option."
            )



if __name__ == "__main__":
    main()