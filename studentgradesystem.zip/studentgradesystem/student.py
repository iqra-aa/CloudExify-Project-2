class Student:

    def __init__(self, student_id, name):
        self.student_id = student_id
        self.name = name
        self.grades = {}


    def add_grade(self, subject, grade):
        self.grades[subject] = grade


    def calculate_average(self):
        if len(self.grades) == 0:
            return 0

        total = sum(self.grades.values())
        return total / len(self.grades)


    def get_status(self):
        average = self.calculate_average()

        if average >= 50:
            return "Pass"
        else:
            return "Fail"


    def display_student(self):

        print("\n-------------------------")
        print(f"ID      : {self.student_id}")
        print(f"Name    : {self.name}")

        print("Grades:")

        if self.grades:
            for subject, grade in self.grades.items():
                print(f"{subject}: {grade}")
        else:
            print("No grades added.")

        print(
            f"Average : {self.calculate_average():.2f}"
        )

        print(
            f"Status  : {self.get_status()}"
        )

        print("-------------------------")