def print_header(title):
    """
    Display a formatted heading.
    """

    print("\n" + "=" * 45)
    print(title.center(45))
    print("=" * 45)



def get_non_empty_input(prompt):
    """
    Get text input that cannot be empty.
    """

    while True:

        value = input(prompt).strip()

        if value:
            return value

        print("Input cannot be empty.")



def get_float(prompt):
    """
    Get a valid decimal number.
    """

    while True:

        try:

            value = float(input(prompt))

            if value < 0:
                print("Grade cannot be negative.")
                continue

            return value


        except ValueError:

            print("Please enter a valid number.")



def get_int(prompt):
    """
    Get a valid integer.
    """

    while True:

        try:

            return int(input(prompt))


        except ValueError:

            print("Please enter a valid integer.")



def confirm_action(message):

    """
    Ask user for confirmation.
    """

    while True:

        choice = input(
            f"{message} (Y/N): "
        ).upper().strip()


        if choice == "Y":
            return True


        if choice == "N":
            return False


        print("Please enter Y or N.")